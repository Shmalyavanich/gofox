<div class="uk-width-1-1">
	<?php

		foreach ($widgets as &$widget) {
			echo $widget;
		}

	?>
</div>
